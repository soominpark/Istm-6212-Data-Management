#!/usr/bin/env python

"""
A filter that split lines of text into one word per line.
"""

import fileinput
import re


def process(line):
    """For each line of input, take each word out of the line and print it."""
   
    """For each line of input, remove needless characters and patterns 
    using Regular expression since 'split' can deal with only one delimeter. """
    SplitedLine = re.split(r"[\:\,\'\.\;\[\]\(\)\-\!\"\?\n\s]*", line[:-1])
    
    """Take the words whose length is more than 2 to match with the '\{2,}' option. """ 
    for i in SplitedLine: 
        if (len(i) >= 2):
            print(i)


for line in fileinput.input():
    process(line)

