#!/usr/bin/env python

"""
A filter that that removes 10 stop words. 
"""

import fileinput
import re


def process(line):
    
    """ Define 10 Stop words. """
    stopWords = ["and", "again", "because", "both", "for", "do", "have", "into", "other", "with"]
    line = line[:-1]    
    
    """ Export only the words that are not included in the stop words list. """
    if (line not in stopWords):
        print(line)


for line in fileinput.input():
    process(line)
